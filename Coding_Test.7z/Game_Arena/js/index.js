
var one = document.getElementById("section--1");
var two = document.getElementById("section--2");
var three = document.getElementById("section--3");
var four = document.getElementById("section--4");
var five = document.getElementById("section--5");
var six = document.getElementById("section--6");
var seven = document.getElementById("section--7");
var eight = document.getElementById("section--8");

function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }



const renderAll = async () => {


    let url = `http://localhost:3000/games`;
  

    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataAll").innerHTML = temp;
}


const renderPS3 = async () => {
    let url = `http://localhost:3000/games?platform=PlayStation 3`;
    // let url = `http://localhost:3000/UserTemplate/10`;
    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataPS3").innerHTML = temp;
}

const renderPSVita = async () => {
    let url = `http://localhost:3000/games?platform=PlayStation Vita`;
  

    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataPSVita").innerHTML = temp;
}


const renderXBOX = async () => {
    let url = `http://localhost:3000/games?platform=Xbox 360`;
  

    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataXBOX").innerHTML = temp;
}

const renderPC = async () => {
    let url = `http://localhost:3000/games?platform=PC`;
  

    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataPC").innerHTML = temp;
}

const renderNintendo = async () => {
    let url = `http://localhost:3000/games?platform=Nintendo DS`;
  

    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataNintendo").innerHTML = temp;
}

const renderiPhone = async () => {
    let url = `http://localhost:3000/games?platform=iPhone`;
  

    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataiPhone").innerHTML = temp;
}

const renderAndroid = async () => {
    let url = `http://localhost:3000/games?platform=Android`;
  

    const res = await fetch(url);
    const games = await res.json();
    console.log(games);

    var temp ="";

    games.forEach(u => {
        temp +="<tr>";
        temp += "<td>"+u.title+"</td>";
        temp += "<td>"+u.platform+"</td>";
        temp += "<td>"+u.score+"</td>";
        temp += "<td>"+u.genre+"</td>";
        temp += "<td>"+u.editors_choice+"</td>";
    });

    document.getElementById("dataAndroid").innerHTML = temp;
}





